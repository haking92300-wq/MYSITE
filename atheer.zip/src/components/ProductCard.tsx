import { useState } from 'react';
import { Check, Plus } from 'lucide-react';
import type { Language, Product } from '../types/store';
import { getCategoryLabel, getLocalizedProduct, UI_COPY } from '../i18n/translations';
import { formatPrice } from '../utils/storeLogic';
import { ProductImage } from './ProductImage';

interface ProductCardProps {
  lang: Language;
  product: Product;
  onOpenProduct: (slug: string) => void;
  onAddToCart: (product: Product, variant: string) => void;
}

export function ProductCard({
  lang,
  product,
  onOpenProduct,
  onAddToCart,
}: ProductCardProps) {
  const [justAdded, setJustAdded] = useState(false);
  const t = UI_COPY[lang];
  const localized = getLocalizedProduct(product, lang);

  const handleQuickAdd = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    onAddToCart(product, product.variants[0]);
    setJustAdded(true);
    window.setTimeout(() => setJustAdded(false), 1200);
  };

  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-[#261F40] bg-[#0E0C18] transition-all duration-200 ease-out hover:-translate-y-0.5 hover:border-[#8B5CF6]/65 hover:shadow-[0_18px_38px_-16px_rgba(139,92,246,0.42)]">
      <a
        href={`/products/${product.slug}`}
        onClick={(e) => {
          e.preventDefault();
          onOpenProduct(product.slug);
        }}
        className="block border-b border-[#261F40] focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#A78BFA]"
      >
        <ProductImage
          src={product.image}
          alt={localized.imageAlt}
          title={localized.name}
          imageTone={product.imageTone}
          aspectClass="h-40 sm:h-44"
          hoverZoom
        />
      </a>

      <div className="flex flex-1 flex-col justify-between p-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium tracking-wider uppercase text-[#A8A1C2]">
            <span>{getCategoryLabel(product.category, lang)}</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#C4B5FD]">{t.card.inStock}</span>
          </div>

          <h3 className="mt-2 font-display text-[17px] font-semibold leading-snug text-[#F5F3FF]">
            <a
              href={`/products/${product.slug}`}
              onClick={(e) => {
                e.preventDefault();
                onOpenProduct(product.slug);
              }}
              className="transition-colors hover:text-[#DDD6FE] hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
            >
              {localized.name}
            </a>
          </h3>

          <p className="mt-1.5 line-clamp-2 text-sm leading-relaxed text-[#A8A1C2]">
            {localized.subtitle}
          </p>
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-[#261F40] pt-4">
          <span className="font-mono text-[15px] font-semibold text-[#F5F3FF] tabular-nums">
            {formatPrice(product.priceEgp, lang)}
          </span>

          <button
            type="button"
            onClick={handleQuickAdd}
            aria-label={`${t.card.addToBag}: ${localized.name}`}
            className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all duration-150 active:scale-[0.98] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA] ${
              justAdded
                ? 'bg-[#6D28D9] text-white shadow-[0_0_20px_rgba(139,92,246,0.5)]'
                : 'bg-[#7C3AED] text-white hover:bg-[#6D28D9] hover:shadow-[0_6px_20px_-6px_rgba(124,58,237,0.7)]'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{t.card.added}</span>
              </>
            ) : (
              <>
                <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{t.card.addToBag}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
