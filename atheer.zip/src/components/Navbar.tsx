import { useState } from 'react';
import { Menu, ShoppingBag, X } from 'lucide-react';
import type { Language } from '../types/store';
import { UI_COPY } from '../i18n/translations';

interface NavbarProps {
  lang: Language;
  currentPath: string;
  cartCount: number;
  onNavigate: (path: string) => void;
  onOpenCart: () => void;
}

export function Navbar({
  lang,
  currentPath,
  cartCount,
  onNavigate,
  onOpenCart,
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const t = UI_COPY[lang];

  const navLinks = [
    { label: t.nav.home, path: '/' },
    { label: t.nav.products, path: '/products' },
    { label: t.nav.keyboards, path: '/products?category=Keyboards' },
    {
      label: t.nav.controllers,
      path: '/products?category=Gaming%20Controllers',
    },
    { label: t.nav.checkout, path: '/checkout' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, path: string) => {
    e.preventDefault();
    setMobileOpen(false);
    onNavigate(path);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[#261F40] bg-[#07060D]/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="/"
          onClick={(e) => handleLinkClick(e, '/')}
          className="font-display text-xl font-bold tracking-tight text-[#F5F3FF] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#A78BFA]"
        >
          {t.brand}
        </a>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-[#A8A1C2]"
        >
          {navLinks.map((link) => {
            const isActive =
              link.path === '/'
                ? currentPath === '/'
                : currentPath === link.path ||
                  (link.path === '/products' && currentPath.startsWith('/products/'));

            return (
              <a
                key={link.path}
                href={link.path}
                onClick={(e) => handleLinkClick(e, link.path)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative py-1 whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#A78BFA] ${
                  isActive
                    ? 'text-[#F5F3FF] after:absolute after:inset-x-0 after:bottom-0 after:h-[1.5px] after:bg-[#A78BFA]'
                    : 'hover:text-[#F5F3FF]'
                }`}
              >
                {link.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action + Mobile Menu Trigger */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenCart}
            aria-label={t.nav.openBagLabel(cartCount)}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-[#7C3AED] px-4 py-2 text-xs font-semibold text-white shadow-[0_6px_20px_-6px_rgba(124,58,237,0.65)] transition-all duration-150 hover:bg-[#6D28D9] active:scale-[0.98] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
          >
            <ShoppingBag className="h-3.5 w-3.5" aria-hidden="true" />
            <span className="tabular-nums">
              {t.nav.bag} ({cartCount})
            </span>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? t.nav.closeMenu : t.nav.openMenu}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-[#2A2246] bg-[#141122] text-[#F5F3FF] transition-colors hover:border-[#8B5CF6]/60 hover:bg-[#1D1831] md:hidden focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileOpen && (
        <nav
          aria-label="Mobile navigation"
          className="border-t border-[#261F40] bg-[#0B0914] px-4 py-3 md:hidden"
        >
          <div className="flex flex-col gap-1">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <a
                  key={link.path}
                  href={link.path}
                  onClick={(e) => handleLinkClick(e, link.path)}
                  className={`flex min-h-[44px] items-center justify-between rounded-lg px-3 text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#1A1530] text-[#F5F3FF]'
                      : 'text-[#A8A1C2] hover:bg-[#141122] hover:text-[#F5F3FF]'
                  }`}
                >
                  <span>{link.label}</span>
                </a>
              );
            })}
          </div>
        </nav>
      )}
    </header>
  );
}
