import { PRODUCT_CATEGORIES } from '../data/products';
import type { Language } from '../types/store';
import { getCategoryLabel, UI_COPY } from '../i18n/translations';

interface FooterProps {
  lang: Language;
  onNavigate: (path: string) => void;
  onToggleLanguage: () => void;
}

export function Footer({ lang, onNavigate, onToggleLanguage }: FooterProps) {
  const t = UI_COPY[lang];

  const handleLink = (e: React.MouseEvent<HTMLAnchorElement>, path: string) => {
    e.preventDefault();
    onNavigate(path);
  };

  return (
    <footer className="border-t border-[#261F40] bg-[#090811]">
      <div className="mx-auto max-w-[1200px] px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-12">
          <div className="md:col-span-5">
            <a
              href="/"
              onClick={(e) => handleLink(e, '/')}
              className="font-display text-xl font-bold tracking-tight text-[#F5F3FF]"
            >
              {t.brand}
            </a>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-[#A8A1C2]">
              {t.footer.about}
            </p>
            <button
              type="button"
              onClick={onToggleLanguage}
              aria-label={t.switchLanguageLabel}
              className="mt-5 inline-flex min-h-[40px] items-center rounded-lg border border-[#322952] bg-[#141122] px-4 py-2 text-xs font-semibold text-[#F5F3FF] transition-colors hover:border-[#8B5CF6]/60 hover:bg-[#1D1831] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
            >
              {t.switchLanguage}
            </button>
          </div>

          <div className="md:col-span-3">
            <h3 className="text-xs font-semibold tracking-wider uppercase text-[#F5F3FF]">
              {t.footer.categoriesTitle}
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-[#A8A1C2]">
              {PRODUCT_CATEGORIES.map((category) => (
                <li key={category}>
                  <a
                    href={`/products?category=${encodeURIComponent(category)}`}
                    onClick={(e) =>
                      handleLink(
                        e,
                        `/products?category=${encodeURIComponent(category)}`
                      )
                    }
                    className="transition-colors hover:text-[#DDD6FE]"
                  >
                    {getCategoryLabel(category, lang)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2">
            <h3 className="text-xs font-semibold tracking-wider uppercase text-[#F5F3FF]">
              {t.footer.storefrontTitle}
            </h3>
            <ul className="mt-4 space-y-2.5 text-sm text-[#A8A1C2]">
              <li>
                <a
                  href="/"
                  onClick={(e) => handleLink(e, '/')}
                  className="transition-colors hover:text-[#DDD6FE]"
                >
                  {t.footer.homepage}
                </a>
              </li>
              <li>
                <a
                  href="/products"
                  onClick={(e) => handleLink(e, '/products')}
                  className="transition-colors hover:text-[#DDD6FE]"
                >
                  {t.footer.allProducts}
                </a>
              </li>
              <li>
                <a
                  href="/cart"
                  onClick={(e) => handleLink(e, '/cart')}
                  className="transition-colors hover:text-[#DDD6FE]"
                >
                  {t.footer.shoppingBag}
                </a>
              </li>
              <li>
                <a
                  href="/checkout"
                  onClick={(e) => handleLink(e, '/checkout')}
                  className="transition-colors hover:text-[#DDD6FE]"
                >
                  {t.footer.checkout}
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h3 className="text-xs font-semibold tracking-wider uppercase text-[#F5F3FF]">
              {t.footer.studioTitle}
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-[#A8A1C2]">
              <li>{t.footer.location}</li>
              <li>{t.footer.hours}</li>
              <li>
                <a
                  href="tel:01033528258"
                  dir="ltr"
                  className="inline-block font-mono tabular-nums transition-colors hover:text-[#DDD6FE]"
                >
                  01033528258
                </a>
              </li>
              <li dir="ltr" className="text-start">
                support@atheer.eg
              </li>
              <li>{t.footer.warranty}</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-[#261F40] pt-8 font-[Georgia] text-xs text-[#A8A1C2] sm:flex-row sm:items-center">
          <p>{t.footer.copyright}</p>
          <p className="font-mono tabular-nums">{t.footer.bottomNote}</p>
        </div>
      </div>
    </footer>
  );
}
