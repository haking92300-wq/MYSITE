import { useState } from 'react';
import { Monitor } from 'lucide-react';

interface ProductImageProps {
  src: string;
  alt: string;
  title?: string;
  imageTone?: 'light' | 'dark';
  aspectClass?: string;
  className?: string;
  hoverZoom?: boolean;
  priority?: boolean;
}

export function ProductImage({
  src,
  alt,
  title,
  imageTone = 'dark',
  aspectClass = 'aspect-[4/3]',
  className = '',
  hoverZoom = false,
  priority = false,
}: ProductImageProps) {
  const [failed, setFailed] = useState(false);

  const isLightStage = imageTone === 'light';

  return (
    <div
      className={`relative overflow-hidden ${
        isLightStage
          ? 'bg-gradient-to-b from-white via-[#FAF8FF] to-[#EFEAFF]'
          : 'bg-[#090811]'
      } ${aspectClass} ${className}`}
    >
      {!failed ? (
        <img
          src={src}
          alt={alt}
          referrerPolicy="no-referrer"
          loading="eager"
          decoding={priority ? 'sync' : 'async'}
          onError={() => setFailed(true)}
          className={`h-full w-full transition-transform duration-300 ease-out ${
            isLightStage ? 'object-contain p-5 sm:p-6' : 'object-cover'
          } ${hoverZoom ? 'group-hover:scale-[1.04]' : ''}`}
        />
      ) : (
        <div
          role="img"
          aria-label={alt}
          className="flex h-full w-full flex-col items-center justify-center gap-2 bg-gradient-to-br from-[#141122] via-[#0E0C18] to-[#06060A] p-6 text-center"
        >
          <Monitor className="h-8 w-8 text-[#A78BFA]" aria-hidden="true" />
          <span className="text-sm font-medium text-[#F5F3FF]">
            {title || alt}
          </span>
        </div>
      )}
    </div>
  );
}
