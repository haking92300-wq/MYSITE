import { useEffect } from 'react';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import type { CartItem, Language, Product } from '../types/store';
import { getLocalizedProduct, UI_COPY } from '../i18n/translations';
import { calculateTotals, formatPrice } from '../utils/storeLogic';
import { ProductImage } from './ProductImage';

interface CartDrawerProps {
  lang: Language;
  open: boolean;
  cart: CartItem[];
  products: Product[];
  onClose: () => void;
  onUpdateQuantity: (productId: string, variant: string, quantity: number) => void;
  onRemoveItem: (productId: string, variant: string) => void;
  onNavigate: (path: string) => void;
}

export function CartDrawer({
  lang,
  open,
  cart,
  products,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onNavigate,
}: CartDrawerProps) {
  const summary = calculateTotals(cart, products);
  const t = UI_COPY[lang];

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const go = (path: string) => {
    onClose();
    onNavigate(path);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-label={t.drawer.title}
    >
      <div
        onClick={onClose}
        className="animate-backdrop-in fixed inset-0 bg-black/70 backdrop-blur-[3px]"
      />

      <aside className="animate-drawer-in relative z-10 flex h-full w-full max-w-md flex-col border-s border-[#261F40] bg-[#0B0914] shadow-[0_0_60px_rgba(124,58,237,0.22)]">
        <div className="flex items-center justify-between border-b border-[#261F40] bg-[#0E0C18] px-6 py-4">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="h-4 w-4 text-[#A78BFA]" aria-hidden="true" />
            <h2 className="font-display text-lg font-semibold text-[#F5F3FF]">
              {t.drawer.title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.drawer.close}
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-[#A8A1C2] transition-colors hover:bg-[#19152B] hover:text-[#F5F3FF] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        {summary.detailedItems.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full border border-[#2E2550] bg-[#141122] text-[#C4B5FD]">
              <ShoppingBag className="h-6 w-6" aria-hidden="true" />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold text-[#F5F3FF]">
              {t.drawer.emptyTitle}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-[#A8A1C2]">
              {t.drawer.emptyBody}
            </p>
            <button
              type="button"
              onClick={() => go('/products')}
              className="mt-6 inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#6D28D9]"
            >
              <span>{t.drawer.browse}</span>
              <ArrowRight className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
            </button>
          </div>
        ) : (
          <>
            <div className="border-b border-[#261F40] bg-[#17122B] px-6 py-2.5 text-xs font-medium text-[#DDD6FE]">
              {summary.remainingForFreeShippingEgp === 0
                ? t.drawer.freeShippingUnlocked
                : t.drawer.freeShippingRemaining(
                    formatPrice(summary.remainingForFreeShippingEgp, lang)
                  )}
            </div>

            <ul className="flex-1 divide-y divide-[#261F40] overflow-y-auto px-6">
              {summary.detailedItems.map(({ product, variant, quantity, lineTotalEgp }) => {
                const localized = getLocalizedProduct(product, lang);
                const variantIndex = product.variants.indexOf(variant);
                const variantLabel =
                  variantIndex >= 0
                    ? localized.variants[variantIndex]?.label ?? variant
                    : variant;

                return (
                  <li
                    key={`${product.id}-${variant}`}
                    className="flex gap-4 py-5"
                  >
                    <button
                      type="button"
                      onClick={() => go(`/products/${product.slug}`)}
                      aria-label={localized.name}
                      className="h-16 w-20 shrink-0 overflow-hidden rounded-lg border border-[#261F40] bg-[#141122]"
                    >
                      <ProductImage
                        src={product.image}
                        alt={localized.imageAlt}
                        title={localized.name}
                        imageTone={product.imageTone}
                        aspectClass="aspect-[4/3] h-full w-full"
                      />
                    </button>

                    <div className="flex flex-1 flex-col justify-between">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <button
                            type="button"
                            onClick={() => go(`/products/${product.slug}`)}
                            className="text-start text-sm font-semibold text-[#F5F3FF] hover:text-[#DDD6FE] hover:underline"
                          >
                            {localized.name}
                          </button>
                          <p className="mt-0.5 text-xs text-[#A8A1C2]">
                            {variantLabel}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(product.id, variant)}
                          aria-label={`${t.drawer.remove} ${localized.name}`}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-md text-[#A8A1C2] transition-colors hover:bg-[#1D1831] hover:text-[#F5F3FF]"
                        >
                          <Trash2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>

                      <div className="mt-3 flex items-center justify-between">
                        <div className="inline-flex items-center rounded-lg border border-[#2A2246] bg-[#141122]">
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateQuantity(product.id, variant, quantity - 1)
                            }
                            aria-label={`${t.pdp.decreaseQty}: ${localized.name}`}
                            className="flex h-8 w-8 items-center justify-center text-[#F5F3FF] transition-colors hover:bg-[#1F1A36]"
                          >
                            <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <span className="min-w-[2rem] text-center font-mono text-xs font-medium text-[#F5F3FF] tabular-nums">
                            {quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateQuantity(product.id, variant, quantity + 1)
                            }
                            aria-label={`${t.pdp.increaseQty}: ${localized.name}`}
                            className="flex h-8 w-8 items-center justify-center text-[#F5F3FF] transition-colors hover:bg-[#1F1A36]"
                          >
                            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>

                        <span className="font-mono text-sm font-medium text-[#F5F3FF] tabular-nums">
                          {formatPrice(lineTotalEgp, lang)}
                        </span>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>

            <div className="border-t border-[#261F40] bg-[#0E0C18] p-6">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#A8A1C2]">{t.drawer.subtotal}</span>
                <span className="font-mono font-semibold text-[#F5F3FF] tabular-nums">
                  {formatPrice(summary.subtotalEgp, lang)}
                </span>
              </div>
              <div className="mt-1.5 flex items-center justify-between text-xs text-[#A8A1C2]">
                <span>{t.drawer.shipping}</span>
                <span className="font-mono tabular-nums">
                  {summary.shippingEgp === 0
                    ? t.drawer.complimentary
                    : formatPrice(summary.shippingEgp, lang)}
                </span>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => go('/cart')}
                  className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-[#322952] bg-[#141122] px-4 py-2.5 text-sm font-semibold text-[#F5F3FF] transition-colors hover:border-[#8B5CF6]/60 hover:bg-[#1D1831] whitespace-nowrap"
                >
                  {t.drawer.viewBag}
                </button>
                <button
                  type="button"
                  onClick={() => go('/checkout')}
                  className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-lg bg-[#7C3AED] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#6D28D9] whitespace-nowrap"
                >
                  <span>{t.drawer.checkout}</span>
                  <ArrowRight className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
                </button>
              </div>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
