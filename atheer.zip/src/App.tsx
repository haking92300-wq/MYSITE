import { useCallback, useEffect, useState } from 'react';
import { PRODUCT_CATEGORIES, PRODUCTS } from './data/products';
import type { CartItem, Language, Product, ProductCategory } from './types/store';
import { getLocalizedProduct, UI_COPY } from './i18n/translations';
import {
  addToCart,
  getCartCount,
  removeFromCart,
  updateCartQuantity,
} from './utils/storeLogic';
import { Navbar } from './components/Navbar';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { CartCheckoutPage } from './pages/CartCheckoutPage';

const CART_STORAGE_KEY = 'atheer_cart_v1';
const LANG_STORAGE_KEY = 'atheer_lang_v1';

function readInitialLang(): Language {
  try {
    const stored = window.localStorage.getItem(LANG_STORAGE_KEY);
    if (stored === 'en' || stored === 'ar') return stored;
  } catch {
    // Ignore storage access errors
  }
  return 'ar';
}

function readInitialCart(): CartItem[] {
  try {
    const raw = window.localStorage.getItem(CART_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (entry) =>
        typeof entry?.productId === 'string' &&
        typeof entry?.variant === 'string' &&
        typeof entry?.quantity === 'number'
    );
  } catch {
    return [];
  }
}

function getFullLocationPath(): string {
  return `${window.location.pathname}${window.location.search}`;
}

function parseCategoryFromSearch(search: string): ProductCategory | 'All' {
  const params = new URLSearchParams(search);
  const category = params.get('category');
  if (category && (PRODUCT_CATEGORIES as string[]).includes(category)) {
    return category as ProductCategory;
  }
  return 'All';
}

export default function App() {
  const [lang, setLang] = useState<Language>(readInitialLang);
  const [currentLocation, setCurrentLocation] = useState<string>(getFullLocationPath);
  const [cart, setCart] = useState<CartItem[]>(readInitialCart);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.title =
      lang === 'ar'
        ? 'أثير | Atheer — إكسسوارات الكمبيوتر والألعاب'
        : 'Atheer — Precision Computer & Gaming Accessories';
    try {
      window.localStorage.setItem(LANG_STORAGE_KEY, lang);
    } catch {
      // Ignore storage errors
    }
  }, [lang]);

  useEffect(() => {
    try {
      window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors
    }
  }, [cart]);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentLocation(getFullLocationPath());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const toggleLanguage = useCallback(() => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  }, []);

  const navigate = useCallback((path: string) => {
    if (path !== getFullLocationPath()) {
      window.history.pushState(null, '', path);
      setCurrentLocation(path);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleAddToCart = useCallback(
    (product: Product, variant: string, quantity = 1) => {
      setCart((prev) => addToCart(prev, product.id, variant, quantity));
      const productName = getLocalizedProduct(product, lang).name;
      const msg = UI_COPY[lang].toastAdded(productName);
      setToastMessage(msg);
      window.setTimeout(() => {
        setToastMessage((prev) => (prev === msg ? null : prev));
      }, 2600);
    },
    [lang]
  );

  const handleUpdateQuantity = useCallback(
    (productId: string, variant: string, quantity: number) => {
      setCart((prev) => updateCartQuantity(prev, productId, variant, quantity));
    },
    []
  );

  const handleRemoveItem = useCallback((productId: string, variant: string) => {
    setCart((prev) => removeFromCart(prev, productId, variant));
  }, []);

  const handleClearCart = useCallback(() => {
    setCart([]);
  }, []);

  const pathname = currentLocation.split('?')[0];
  const search = currentLocation.includes('?')
    ? `?${currentLocation.split('?')[1]}`
    : '';
  const cartCount = getCartCount(cart);
  const t = UI_COPY[lang];

  const renderPage = () => {
    if (pathname === '/' || pathname === '') {
      return (
        <HomePage
          lang={lang}
          products={PRODUCTS}
          onNavigate={navigate}
          onAddToCart={handleAddToCart}
          onToggleLanguage={toggleLanguage}
        />
      );
    }

    if (pathname === '/products') {
      return (
        <ProductsPage
          lang={lang}
          products={PRODUCTS}
          initialCategory={parseCategoryFromSearch(search)}
          onNavigate={navigate}
          onAddToCart={handleAddToCart}
        />
      );
    }

    if (pathname.startsWith('/products/')) {
      const slug = pathname.replace('/products/', '').trim();
      const matched = PRODUCTS.find((p) => p.slug === slug);
      return (
        <ProductDetailPage
          lang={lang}
          product={matched}
          allProducts={PRODUCTS}
          onNavigate={navigate}
          onAddToCart={handleAddToCart}
        />
      );
    }

    if (pathname === '/cart' || pathname === '/checkout') {
      return (
        <CartCheckoutPage
          lang={lang}
          mode={pathname === '/checkout' ? 'checkout' : 'cart'}
          cart={cart}
          products={PRODUCTS}
          onNavigate={navigate}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
          onClearCart={handleClearCart}
        />
      );
    }

    return (
      <HomePage
        lang={lang}
        products={PRODUCTS}
        onNavigate={navigate}
        onAddToCart={handleAddToCart}
        onToggleLanguage={toggleLanguage}
      />
    );
  };

  return (
    <div className="flex min-h-screen flex-col bg-transparent text-[#F5F3FF]">
      <Navbar
        lang={lang}
        currentPath={currentLocation}
        cartCount={cartCount}
        onNavigate={navigate}
        onOpenCart={() => setCartDrawerOpen(true)}
      />

      <main className="flex-1">
        <div key={`${pathname}-${lang}`} className="animate-page-enter">
          {renderPage()}
        </div>
      </main>

      <Footer
        lang={lang}
        onNavigate={navigate}
        onToggleLanguage={toggleLanguage}
      />

      <CartDrawer
        lang={lang}
        open={cartDrawerOpen}
        cart={cart}
        products={PRODUCTS}
        onClose={() => setCartDrawerOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onNavigate={navigate}
      />

      {/* Accessible Cart Toast Feedback */}
      <div
        aria-live="polite"
        className="pointer-events-none fixed end-4 bottom-5 z-50 flex justify-end sm:end-6"
      >
        {toastMessage && (
          <div className="animate-toast-in pointer-events-auto flex items-center gap-3 rounded-xl border border-[#4C3585] bg-[#130E24] px-4 py-3 text-xs font-medium text-[#F5F3FF] shadow-[0_12px_32px_rgba(124,58,237,0.35)]">
            <span>{toastMessage}</span>
            <button
              type="button"
              onClick={() => setCartDrawerOpen(true)}
              className="font-semibold text-[#C4B5FD] underline underline-offset-4 hover:text-white"
            >
              {t.drawer.viewBag}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
