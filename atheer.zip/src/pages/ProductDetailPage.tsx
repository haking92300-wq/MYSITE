import { useEffect, useState } from 'react';
import { ArrowLeft, Check, Minus, Plus, ShieldCheck, Star, Truck } from 'lucide-react';
import type { Language, Product } from '../types/store';
import { getCategoryLabel, getLocalizedProduct, UI_COPY } from '../i18n/translations';
import { formatPrice } from '../utils/storeLogic';
import { ProductCard } from '../components/ProductCard';
import { ProductImage } from '../components/ProductImage';

interface ProductDetailPageProps {
  lang: Language;
  product: Product | undefined;
  allProducts: Product[];
  onNavigate: (path: string) => void;
  onAddToCart: (product: Product, variant: string, quantity?: number) => void;
}

export function ProductDetailPage({
  lang,
  product,
  allProducts,
  onNavigate,
  onAddToCart,
}: ProductDetailPageProps) {
  const [selectedVariant, setSelectedVariant] = useState(
    product?.variants[0] ?? ''
  );
  const [quantity, setQuantity] = useState(1);
  const [addedFeedback, setAddedFeedback] = useState(false);
  const t = UI_COPY[lang];

  useEffect(() => {
    if (product) {
      setSelectedVariant(product.variants[0]);
      setQuantity(1);
      setAddedFeedback(false);
    }
  }, [product]);

  if (!product) {
    return (
      <section className="mx-auto max-w-[1200px] px-4 py-20 text-center sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl font-bold text-[#F5F3FF]">
          {t.pdp.notFoundTitle}
        </h1>
        <p className="mt-3 text-sm text-[#A8A1C2]">{t.pdp.notFoundBody}</p>
        <button
          type="button"
          onClick={() => onNavigate('/products')}
          className="mt-6 inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#6D28D9]"
        >
          <ArrowLeft className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
          <span>{t.pdp.backToCatalog}</span>
        </button>
      </section>
    );
  }

  const localized = getLocalizedProduct(product, lang);
  const relatedProducts = allProducts
    .filter((p) => p.id !== product.id)
    .sort((a, b) => (a.category === product.category ? -1 : b.category === product.category ? 1 : 0))
    .slice(0, 3);

  const handleAdd = () => {
    onAddToCart(product, selectedVariant, quantity);
    setAddedFeedback(true);
    window.setTimeout(() => setAddedFeedback(false), 1500);
  };

  const handleBuyNow = () => {
    onAddToCart(product, selectedVariant, quantity);
    onNavigate('/checkout');
  };

  return (
    <section className="mx-auto max-w-[1200px] px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
      {/* Breadcrumb Navigation */}
      <nav aria-label="Breadcrumb" className="mb-8 flex items-center gap-2 text-xs text-[#A8A1C2]">
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('/');
          }}
          className="transition-colors hover:text-[#F5F3FF]"
        >
          {t.nav.home}
        </a>
        <span aria-hidden="true">/</span>
        <a
          href="/products"
          onClick={(e) => {
            e.preventDefault();
            onNavigate('/products');
          }}
          className="transition-colors hover:text-[#F5F3FF]"
        >
          {t.nav.products}
        </a>
        <span aria-hidden="true">/</span>
        <a
          href={`/products?category=${encodeURIComponent(product.category)}`}
          onClick={(e) => {
            e.preventDefault();
            onNavigate(`/products?category=${encodeURIComponent(product.category)}`);
          }}
          className="transition-colors hover:text-[#F5F3FF]"
        >
          {getCategoryLabel(product.category, lang)}
        </a>
        <span aria-hidden="true">/</span>
        <span className="truncate font-medium text-[#F5F3FF]">{localized.name}</span>
      </nav>

      {/* Main PDP Contiguous Split */}
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12">
        {/* Left: Product Gallery & Highlights */}
        <div className="lg:col-span-7">
          <div className="mx-auto max-w-lg overflow-hidden rounded-2xl border border-[#2F2552] bg-[#0E0C18] shadow-[0_20px_50px_-24px_rgba(139,92,246,0.4)]">
            <ProductImage
              src={product.image}
              alt={localized.imageAlt}
              title={localized.name}
              imageTone={product.imageTone}
              aspectClass="h-60 sm:h-72"
              priority
            />
          </div>

          <div className="mt-8 rounded-2xl border border-[#261F40] bg-[#0E0C18] p-6 sm:p-8">
            <h2 className="font-display text-lg font-semibold text-[#F5F3FF]">
              {t.pdp.highlightsTitle}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-[#A8A1C2]">
              {localized.description}
            </p>
            <ul className="mt-5 space-y-3 border-t border-[#261F40] pt-5">
              {localized.highlights.map((highlight) => (
                <li
                  key={highlight}
                  className="flex items-start gap-3 text-sm text-[#F5F3FF]"
                >
                  <Check
                    className="mt-0.5 h-4 w-4 shrink-0 text-[#A78BFA]"
                    aria-hidden="true"
                  />
                  <span>{highlight}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-24 rounded-2xl border border-[#261F40] bg-[#0E0C18] p-6 sm:p-8">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-[#A8A1C2]">
              <span className="uppercase tracking-wider text-[#C4B5FD]">
                {getCategoryLabel(product.category, lang)}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">{product.sku}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1 text-[#F5F3FF]">
                <Star className="h-3.5 w-3.5 fill-[#A78BFA] text-[#A78BFA]" aria-hidden="true" />
                <span className="tabular-nums">{product.rating.toFixed(1)}</span>
                <span className="text-[#A8A1C2] tabular-nums">
                  ({product.reviewCount})
                </span>
              </span>
            </div>

            <h1 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F5F3FF] sm:text-3xl">
              {localized.name}
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-[#A8A1C2]">
              {localized.subtitle}
            </p>

            <div className="mt-6 flex items-baseline justify-between border-y border-[#261F40] py-4">
              <span className="font-mono text-2xl font-semibold text-[#F5F3FF] tabular-nums">
                {formatPrice(product.priceEgp, lang)}
              </span>
              <span className="text-xs font-medium text-[#C4B5FD]">
                {t.pdp.inStockFast}
              </span>
            </div>

            {/* Variant Selector */}
            <div className="mt-6">
              <p className="text-xs font-semibold uppercase tracking-wider text-[#F5F3FF]">
                {t.pdp.configuration}
              </p>
              <div className="mt-2.5 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {localized.variants.map((variant) => {
                  const active = selectedVariant === variant.value;
                  return (
                    <button
                      key={variant.value}
                      type="button"
                      onClick={() => setSelectedVariant(variant.value)}
                      aria-pressed={active}
                      className={`min-h-[44px] rounded-lg border px-3.5 py-2 text-start text-xs font-semibold transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA] ${
                        active
                          ? 'border-[#8B5CF6] bg-[#7C3AED] text-white shadow-[0_4px_14px_rgba(124,58,237,0.45)]'
                          : 'border-[#2A2246] bg-[#141122] text-[#F5F3FF] hover:border-[#8B5CF6]/60'
                      }`}
                    >
                      {variant.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity & Action CTAs */}
            <div className="mt-6 space-y-3">
              <div className="flex items-center gap-3">
                <div className="inline-flex h-12 items-center rounded-lg border border-[#2A2246] bg-[#141122]">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label={t.pdp.decreaseQty}
                    className="flex h-12 w-11 items-center justify-center text-[#F5F3FF] transition-colors hover:bg-[#1F1A36]"
                  >
                    <Minus className="h-4 w-4" aria-hidden="true" />
                  </button>
                  <span className="min-w-[2.5rem] text-center font-mono text-sm font-semibold text-[#F5F3FF] tabular-nums">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.min(20, q + 1))}
                    aria-label={t.pdp.increaseQty}
                    className="flex h-12 w-11 items-center justify-center text-[#F5F3FF] transition-colors hover:bg-[#1F1A36]"
                  >
                    <Plus className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleAdd}
                  className={`flex h-12 flex-1 items-center justify-center gap-2 rounded-lg px-5 text-sm font-semibold text-white transition-all duration-150 active:scale-[0.98] whitespace-nowrap ${
                    addedFeedback
                      ? 'bg-[#6D28D9] shadow-[0_0_24px_rgba(139,92,246,0.5)]'
                      : 'bg-[#7C3AED] shadow-[0_8px_24px_-6px_rgba(124,58,237,0.65)] hover:bg-[#6D28D9]'
                  }`}
                >
                  {addedFeedback ? (
                    <>
                      <Check className="h-4 w-4" aria-hidden="true" />
                      <span>{t.pdp.addedToBag}</span>
                    </>
                  ) : (
                    <span>
                      {t.pdp.addToBag} · {formatPrice(product.priceEgp * quantity, lang)}
                    </span>
                  )}
                </button>
              </div>

              <button
                type="button"
                onClick={handleBuyNow}
                className="flex h-12 w-full items-center justify-center rounded-lg border border-[#322952] bg-[#141122] px-5 text-sm font-semibold text-[#F5F3FF] transition-colors hover:border-[#8B5CF6]/60 hover:bg-[#1D1831]"
              >
                {t.pdp.buyNow}
              </button>
            </div>

            {/* Trust Callouts */}
            <div className="mt-6 grid grid-cols-2 gap-3 border-t border-[#261F40] pt-5 text-xs text-[#A8A1C2]">
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 shrink-0 text-[#A78BFA]" aria-hidden="true" />
                <span>{t.pdp.freeDeliveryHint}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 shrink-0 text-[#A78BFA]" aria-hidden="true" />
                <span>{t.pdp.warrantyHint}</span>
              </div>
            </div>

            {/* Technical Specifications Table */}
            <div className="mt-6 border-t border-[#261F40] pt-6">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[#F5F3FF]">
                {t.pdp.specsTitle}
              </h2>
              <dl className="mt-3 divide-y divide-[#261F40]">
                {localized.specs.map((spec) => (
                  <div
                    key={spec.label}
                    className="flex items-center justify-between gap-4 py-2.5 text-xs"
                  >
                    <dt className="text-[#A8A1C2]">{spec.label}</dt>
                    <dd className="text-end font-mono font-medium text-[#F5F3FF] tabular-nums">
                      {spec.value}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <div className="mt-20 border-t border-[#261F40] pt-14">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold tracking-tight text-[#F5F3FF]">
            {t.pdp.relatedTitle}
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('/products')}
            className="text-sm font-semibold text-[#DDD6FE] underline-offset-4 hover:text-white hover:underline"
          >
            {t.pdp.viewCatalog}
          </button>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {relatedProducts.map((related) => (
            <ProductCard
              key={related.id}
              lang={lang}
              product={related}
              onOpenProduct={(slug) => onNavigate(`/products/${slug}`)}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
