import { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  MessageCircle,
  Minus,
  Plus,
  ShoppingBag,
  Trash2,
} from 'lucide-react';
import type {
  CartItem,
  CheckoutFormData,
  CheckoutValidationErrors,
  ConfirmedOrder,
  Language,
  Product,
} from '../types/store';
import {
  getCategoryLabel,
  getLocalizedProduct,
  GOVERNORATES_LIST,
  UI_COPY,
} from '../i18n/translations';
import {
  buildWhatsAppOrderMessage,
  buildWhatsAppRedirectUrl,
  calculateTotals,
  createOrderConfirmation,
  formatPrice,
  validateCheckoutForm,
} from '../utils/storeLogic';
import { ProductImage } from '../components/ProductImage';

interface CartCheckoutPageProps {
  lang: Language;
  mode: 'cart' | 'checkout';
  cart: CartItem[];
  products: Product[];
  onNavigate: (path: string) => void;
  onUpdateQuantity: (productId: string, variant: string, quantity: number) => void;
  onRemoveItem: (productId: string, variant: string) => void;
  onClearCart: () => void;
}

const INITIAL_FORM: CheckoutFormData = {
  fullName: '',
  phone: '',
  email: '',
  address: '',
  governorate: 'Cairo',
  postalCode: '',
  notes: '',
  paymentMethod: 'cod',
};

export function CartCheckoutPage({
  lang,
  mode,
  cart,
  products,
  onNavigate,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartCheckoutPageProps) {
  const [formData, setFormData] = useState<CheckoutFormData>(INITIAL_FORM);
  const [errors, setErrors] = useState<CheckoutValidationErrors>({});
  const [confirmedOrder, setConfirmedOrder] = useState<ConfirmedOrder | null>(null);
  const [whatsappUrl, setWhatsappUrl] = useState<string>('');
  const t = UI_COPY[lang];

  const summary = calculateTotals(cart, products);

  const handleFieldChange = <K extends keyof CheckoutFormData>(
    key: K,
    value: CheckoutFormData[K]
  ) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
    if (key in errors) {
      setErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  };

  const triggerWhatsAppRedirect = (targetUrl: string) => {
    const link = document.createElement('a');
    link.href = targetUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePlaceOrder = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validationErrors = validateCheckoutForm(formData, lang);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      const nameInput = document.getElementById('checkout-name');
      nameInput?.focus();
      return;
    }

    const order = createOrderConfirmation(cart, products, formData);
    const message = buildWhatsAppOrderMessage(order, lang);
    const url = buildWhatsAppRedirectUrl(message);

    setConfirmedOrder(order);
    setWhatsappUrl(url);
    onClearCart();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    triggerWhatsAppRedirect(url);
  };

  const getGovernorateLabel = (value: string) => {
    const match = GOVERNORATES_LIST.find((g) => g.value === value);
    return match ? match[lang] : value;
  };

  if (confirmedOrder) {
    return (
      <section className="mx-auto max-w-[820px] px-4 py-14 sm:px-6 lg:py-20">
        <div className="rounded-2xl border border-[#322952] bg-[#0E0C18] p-8 shadow-[0_20px_50px_-24px_rgba(139,92,246,0.35)] sm:p-10">
          <div className="flex items-center gap-3 text-[#C4B5FD]">
            <CheckCircle2 className="h-7 w-7 shrink-0" aria-hidden="true" />
            <span className="font-mono text-xs font-semibold uppercase tracking-widest">
              {t.checkout.confirmedBadge}
            </span>
          </div>

          <h1 className="mt-4 font-display text-3xl font-bold tracking-tight text-[#F5F3FF]">
            {t.checkout.confirmedTitle(confirmedOrder.orderNumber)}
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-[#A8A1C2]">
            {t.checkout.confirmedBody(confirmedOrder.customer.fullName)}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[48px] items-center gap-2 rounded-lg bg-[#25D366] px-6 py-3 text-sm font-bold text-[#05200E] shadow-[0_8px_24px_-6px_rgba(37,211,102,0.5)] transition-all hover:bg-[#22C35E]"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              <span>{t.checkout.sendWhatsappNow}</span>
            </a>

            <button
              type="button"
              onClick={() => {
                setConfirmedOrder(null);
                setWhatsappUrl('');
                onNavigate('/products');
              }}
              className="inline-flex min-h-[48px] items-center gap-2 rounded-lg border border-[#322952] bg-[#141122] px-5 py-3 text-sm font-semibold text-[#F5F3FF] transition-colors hover:border-[#8B5CF6]/60 hover:bg-[#1D1831]"
            >
              <span>{t.checkout.continueShopping}</span>
              <ArrowRight className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
            </button>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 border-y border-[#261F40] py-6 sm:grid-cols-2">
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A1C2]">
                {t.checkout.recipientTitle}
              </h2>
              <p className="mt-2 text-sm font-semibold text-[#F5F3FF]">
                {confirmedOrder.customer.fullName}
              </p>
              {confirmedOrder.customer.phone && (
                <p className="mt-1 font-mono text-sm text-[#A8A1C2]" dir="ltr">
                  {confirmedOrder.customer.phone}
                </p>
              )}
              {(confirmedOrder.customer.address || confirmedOrder.customer.governorate) && (
                <p className="mt-1 text-sm text-[#A8A1C2]">
                  {[
                    confirmedOrder.customer.address,
                    confirmedOrder.customer.governorate
                      ? getGovernorateLabel(confirmedOrder.customer.governorate)
                      : '',
                    confirmedOrder.customer.postalCode,
                  ]
                    .filter(Boolean)
                    .join(', ')}
                </p>
              )}
            </div>

            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A1C2]">
                {t.checkout.paymentTitle}
              </h2>
              <p className="mt-2 text-sm font-semibold text-[#F5F3FF]">
                {confirmedOrder.customer.paymentMethod === 'cod'
                  ? t.checkout.cod
                  : t.checkout.pos}
              </p>
              <p className="mt-1 text-sm text-[#A8A1C2]">
                {t.checkout.amountDue}{' '}
                <span className="font-mono font-semibold text-[#F5F3FF] tabular-nums">
                  {formatPrice(confirmedOrder.totalEgp, lang)}
                </span>
              </p>
            </div>
          </div>

          <div className="mt-6">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-[#A8A1C2]">
              {t.checkout.receiptTitle}
            </h2>
            <ul className="mt-4 divide-y divide-[#261F40]">
              {confirmedOrder.items.map(({ product, variant, quantity, lineTotalEgp }) => {
                const localized = getLocalizedProduct(product, lang);
                const variantIndex = product.variants.indexOf(variant);
                const variantLabel =
                  variantIndex >= 0
                    ? localized.variants[variantIndex]?.label ?? variant
                    : variant;

                return (
                  <li
                    key={`${product.id}-${variant}`}
                    className="flex items-center justify-between gap-4 py-3 text-sm"
                  >
                    <div>
                      <p className="font-medium text-[#F5F3FF]">
                        {localized.name} × {quantity}
                      </p>
                      <p className="text-xs text-[#A8A1C2]">{variantLabel}</p>
                    </div>
                    <span className="font-mono font-medium text-[#F5F3FF] tabular-nums">
                      {formatPrice(lineTotalEgp, lang)}
                    </span>
                  </li>
                );
              })}
            </ul>

            <div className="mt-4 space-y-2 border-t border-[#261F40] pt-4 text-sm">
              <div className="flex justify-between text-[#A8A1C2]">
                <span>{t.drawer.subtotal}</span>
                <span className="font-mono tabular-nums">
                  {formatPrice(confirmedOrder.subtotalEgp, lang)}
                </span>
              </div>
              <div className="flex justify-between text-[#A8A1C2]">
                <span>{t.checkout.shippingLabel}</span>
                <span className="font-mono tabular-nums">
                  {confirmedOrder.shippingEgp === 0
                    ? t.drawer.complimentary
                    : formatPrice(confirmedOrder.shippingEgp, lang)}
                </span>
              </div>
              <div className="flex justify-between pt-2 text-base font-bold text-[#F5F3FF]">
                <span>{t.checkout.totalLabel}</span>
                <span className="font-mono tabular-nums">
                  {formatPrice(confirmedOrder.totalEgp, lang)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (summary.detailedItems.length === 0) {
    return (
      <section className="mx-auto max-w-[1200px] px-4 py-20 text-center sm:px-6 lg:px-8">
        <div className="mx-auto max-w-md rounded-2xl border border-[#261F40] bg-[#0E0C18] px-8 py-14">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-[#2E2550] bg-[#141122] text-[#C4B5FD]">
            <ShoppingBag className="h-6 w-6" aria-hidden="true" />
          </div>
          <h1 className="mt-5 font-display text-2xl font-bold text-[#F5F3FF]">
            {t.checkout.emptyTitle}
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-[#A8A1C2]">
            {t.checkout.emptyBody}
          </p>
          <button
            type="button"
            onClick={() => onNavigate('/products')}
            className="mt-6 inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-[#7C3AED] px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#6D28D9]"
          >
            <span>{t.checkout.browseHardware}</span>
            <ArrowRight className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-[1200px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
      <div className="mb-8 flex flex-col justify-between gap-4 border-b border-[#261F40] pb-6 sm:flex-row sm:items-end">
        <div>
          <p className="text-xs font-semibold tracking-widest uppercase text-[#C4B5FD]">
            {mode === 'checkout' ? t.checkout.kickerCheckout : t.checkout.kickerCart}
          </p>
          <h1 className="mt-2 font-display text-3xl font-bold tracking-tight text-[#F5F3FF]">
            {mode === 'checkout' ? t.checkout.titleCheckout : t.checkout.titleCart}
          </h1>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('/products')}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#A8A1C2] hover:text-[#F5F3FF]"
        >
          <ArrowLeft className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
          <span>{t.checkout.continueBrowsing}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-12">
        {/* Left: Itemized Cart + Customer Data List Form */}
        <div className="space-y-8 lg:col-span-7">
          <div className="rounded-2xl border border-[#261F40] bg-[#0E0C18] p-6">
            <div className="flex items-center justify-between border-b border-[#261F40] pb-4">
              <h2 className="font-display text-lg font-semibold text-[#F5F3FF]">
                {t.checkout.selectedItems}
              </h2>
              <span className="font-mono text-xs text-[#C4B5FD] tabular-nums">
                {summary.remainingForFreeShippingEgp === 0
                  ? t.checkout.freeShippingApplied
                  : t.checkout.addForFreeShipping(
                      formatPrice(summary.remainingForFreeShippingEgp, lang)
                    )}
              </span>
            </div>

            <ul className="divide-y divide-[#261F40]">
              {summary.detailedItems.map(
                ({ product, variant, quantity, lineTotalEgp }) => {
                  const localized = getLocalizedProduct(product, lang);
                  const variantIndex = product.variants.indexOf(variant);
                  const variantLabel =
                    variantIndex >= 0
                      ? localized.variants[variantIndex]?.label ?? variant
                      : variant;

                  return (
                    <li
                      key={`${product.id}-${variant}`}
                      className="flex flex-col gap-4 py-5 sm:flex-row sm:items-center"
                    >
                      <button
                        type="button"
                        onClick={() => onNavigate(`/products/${product.slug}`)}
                        aria-label={localized.name}
                        className="h-18 w-24 shrink-0 overflow-hidden rounded-lg border border-[#261F40]"
                      >
                        <ProductImage
                          src={product.image}
                          alt={localized.imageAlt}
                          title={localized.name}
                          imageTone={product.imageTone}
                          aspectClass="aspect-[4/3] h-full w-full"
                        />
                      </button>

                      <div className="flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <button
                              type="button"
                              onClick={() => onNavigate(`/products/${product.slug}`)}
                              className="text-start font-display text-base font-semibold text-[#F5F3FF] hover:text-[#DDD6FE] hover:underline"
                            >
                              {localized.name}
                            </button>
                            <p className="mt-0.5 text-xs text-[#A8A1C2]">
                              {getCategoryLabel(product.category, lang)} ·{' '}
                              {variantLabel}
                            </p>
                            <p className="mt-1 font-mono text-xs text-[#A8A1C2] tabular-nums">
                              {formatPrice(product.priceEgp, lang)} {t.checkout.each}
                            </p>
                          </div>

                          <button
                            type="button"
                            onClick={() => onRemoveItem(product.id, variant)}
                            aria-label={`${t.drawer.remove} ${localized.name}`}
                            className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-[#A8A1C2] transition-colors hover:bg-[#1D1831] hover:text-[#F5F3FF]"
                          >
                            <Trash2 className="h-4 w-4" aria-hidden="true" />
                          </button>
                        </div>

                        <div className="mt-4 flex items-center justify-between">
                          <div className="inline-flex items-center rounded-lg border border-[#2A2246] bg-[#141122]">
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateQuantity(product.id, variant, quantity - 1)
                              }
                              aria-label={`${t.pdp.decreaseQty}: ${localized.name}`}
                              className="flex h-9 w-9 items-center justify-center text-[#F5F3FF] hover:bg-[#1F1A36]"
                            >
                              <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                            </button>
                            <span className="min-w-[2.25rem] text-center font-mono text-xs font-semibold text-[#F5F3FF] tabular-nums">
                              {quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateQuantity(product.id, variant, quantity + 1)
                              }
                              aria-label={`${t.pdp.increaseQty}: ${localized.name}`}
                              className="flex h-9 w-9 items-center justify-center text-[#F5F3FF] hover:bg-[#1F1A36]"
                            >
                              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                            </button>
                          </div>

                          <span className="font-mono text-base font-semibold text-[#F5F3FF] tabular-nums">
                            {formatPrice(lineTotalEgp, lang)}
                          </span>
                        </div>
                      </div>
                    </li>
                  );
                }
              )}
            </ul>
          </div>

          {/* Customer Information Data List Form */}
          <form
            id="checkout-form"
            onSubmit={handlePlaceOrder}
            noValidate
            className="rounded-2xl border border-[#261F40] bg-[#0E0C18] p-6 sm:p-8"
          >
            <h2 className="font-display text-lg font-semibold text-[#F5F3FF]">
              {t.checkout.formTitle}
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-[#A8A1C2]">
              {t.checkout.formSubtitle}
            </p>

            <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label
                  htmlFor="checkout-name"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.fullName}
                </label>
                <input
                  id="checkout-name"
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => handleFieldChange('fullName', e.target.value)}
                  placeholder={t.checkout.fullNamePlaceholder}
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#3B2A6B] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
                />
                {errors.fullName && (
                  <p className="mt-1.5 text-xs font-medium text-rose-400" role="alert">
                    {errors.fullName}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="checkout-phone"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.phone}
                </label>
                <input
                  id="checkout-phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleFieldChange('phone', e.target.value)}
                  placeholder={t.checkout.phonePlaceholder}
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#2A2246] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
                />
                {errors.phone && (
                  <p className="mt-1.5 text-xs font-medium text-rose-400" role="alert">
                    {errors.phone}
                  </p>
                )}
              </div>

              <div>
                <label
                  htmlFor="checkout-email"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.email}
                </label>
                <input
                  id="checkout-email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleFieldChange('email', e.target.value)}
                  placeholder={t.checkout.emailPlaceholder}
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#2A2246] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
                />
                {errors.email && (
                  <p className="mt-1.5 text-xs font-medium text-rose-400" role="alert">
                    {errors.email}
                  </p>
                )}
              </div>

              <div className="sm:col-span-2">
                <label
                  htmlFor="checkout-address"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.address}
                </label>
                <input
                  id="checkout-address"
                  type="text"
                  value={formData.address}
                  onChange={(e) => handleFieldChange('address', e.target.value)}
                  placeholder={t.checkout.addressPlaceholder}
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#2A2246] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="checkout-governorate"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.governorate}
                </label>
                <select
                  id="checkout-governorate"
                  value={formData.governorate}
                  onChange={(e) =>
                    handleFieldChange('governorate', e.target.value)
                  }
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#2A2246] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] focus:border-[#8B5CF6] focus:outline-none"
                >
                  {GOVERNORATES_LIST.map((gov) => (
                    <option key={gov.value} value={gov.value}>
                      {gov[lang]}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="checkout-postal"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.postalCode}
                </label>
                <input
                  id="checkout-postal"
                  type="text"
                  value={formData.postalCode}
                  onChange={(e) => handleFieldChange('postalCode', e.target.value)}
                  placeholder={t.checkout.postalPlaceholder}
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#2A2246] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <span className="block text-xs font-semibold text-[#F5F3FF]">
                  {t.checkout.paymentMethod}
                </span>
                <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <label className="flex min-h-[48px] cursor-pointer items-center gap-3 rounded-lg border border-[#2A2246] bg-[#141122] px-4 py-3 text-sm font-medium text-[#F5F3FF] has-[:checked]:border-[#8B5CF6] has-[:checked]:bg-[#1C1435]">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="cod"
                      checked={formData.paymentMethod === 'cod'}
                      onChange={() => handleFieldChange('paymentMethod', 'cod')}
                      className="h-4 w-4 accent-[#8B5CF6]"
                    />
                    <span>{t.checkout.cod}</span>
                  </label>
                  <label className="flex min-h-[48px] cursor-pointer items-center gap-3 rounded-lg border border-[#2A2246] bg-[#141122] px-4 py-3 text-sm font-medium text-[#F5F3FF] has-[:checked]:border-[#8B5CF6] has-[:checked]:bg-[#1C1435]">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="card-on-delivery"
                      checked={formData.paymentMethod === 'card-on-delivery'}
                      onChange={() =>
                        handleFieldChange('paymentMethod', 'card-on-delivery')
                      }
                      className="h-4 w-4 accent-[#8B5CF6]"
                    />
                    <span>{t.checkout.pos}</span>
                  </label>
                </div>
              </div>

              <div className="sm:col-span-2">
                <label
                  htmlFor="checkout-notes"
                  className="block text-xs font-semibold text-[#F5F3FF]"
                >
                  {t.checkout.notes}
                </label>
                <input
                  id="checkout-notes"
                  type="text"
                  value={formData.notes}
                  onChange={(e) => handleFieldChange('notes', e.target.value)}
                  placeholder={t.checkout.notesPlaceholder}
                  className="mt-1.5 h-11 w-full rounded-lg border border-[#2A2246] bg-[#141122] px-3.5 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
                />
              </div>
            </div>
          </form>
        </div>

        {/* Right: Sticky Order Summary */}
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-24 rounded-2xl border border-[#261F40] bg-[#0E0C18] p-6 sm:p-8">
            <h2 className="font-display text-lg font-semibold text-[#F5F3FF]">
              {t.checkout.orderSummary}
            </h2>

            <dl className="mt-6 space-y-3 border-b border-[#261F40] pb-5 text-sm">
              <div className="flex items-center justify-between text-[#A8A1C2]">
                <dt>
                  {t.checkout.itemsLabel(
                    summary.detailedItems.reduce((s, i) => s + i.quantity, 0)
                  )}
                </dt>
                <dd className="font-mono font-medium text-[#F5F3FF] tabular-nums">
                  {formatPrice(summary.subtotalEgp, lang)}
                </dd>
              </div>
              <div className="flex items-center justify-between text-[#A8A1C2]">
                <dt>{t.checkout.shippingLabel}</dt>
                <dd className="font-mono font-medium text-[#F5F3FF] tabular-nums">
                  {summary.shippingEgp === 0
                    ? t.drawer.complimentary
                    : formatPrice(summary.shippingEgp, lang)}
                </dd>
              </div>
            </dl>

            <div className="mt-5 flex items-baseline justify-between">
              <span className="font-display text-base font-semibold text-[#F5F3FF]">
                {t.checkout.totalDue}
              </span>
              <span className="font-mono text-2xl font-bold text-[#DDD6FE] tabular-nums">
                {formatPrice(summary.totalEgp, lang)}
              </span>
            </div>

            <button
              type="submit"
              form="checkout-form"
              className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-[#25D366] px-6 text-sm font-bold text-[#05200E] shadow-[0_8px_24px_-6px_rgba(37,211,102,0.5)] transition-all duration-150 hover:bg-[#22C35E] active:scale-[0.98]"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              <span>
                {t.checkout.placeOrder} · {formatPrice(summary.totalEgp, lang)}
              </span>
            </button>

            <p className="mt-3 text-center text-xs leading-relaxed text-[#C4B5FD]">
              {t.checkout.whatsappHint}
            </p>
            <p className="mt-2 text-center text-xs leading-relaxed text-[#A8A1C2]">
              {t.checkout.footerNote}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
