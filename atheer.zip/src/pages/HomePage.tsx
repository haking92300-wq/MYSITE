import { ArrowRight, Globe } from 'lucide-react';
import { HERO_IMAGE, PRODUCT_CATEGORIES } from '../data/products';
import type { Language, Product } from '../types/store';
import { getCategoryLabel, UI_COPY } from '../i18n/translations';
import { formatPrice } from '../utils/storeLogic';
import { ProductCard } from '../components/ProductCard';
import { ProductImage } from '../components/ProductImage';

interface HomePageProps {
  lang: Language;
  products: Product[];
  onNavigate: (path: string) => void;
  onAddToCart: (product: Product, variant: string) => void;
  onToggleLanguage: () => void;
}

export function HomePage({
  lang,
  products,
  onNavigate,
  onAddToCart,
  onToggleLanguage,
}: HomePageProps) {
  const featuredProducts = products.filter((p) => p.featured).slice(0, 6);
  const t = UI_COPY[lang];

  return (
    <div>
      {/* Section 1: Storefront Hero */}
      <section className="relative overflow-hidden border-b border-[#261F40] bg-gradient-to-b from-[#0E0A1C]/90 via-[#080610]/70 to-transparent">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-28 start-1/2 h-96 w-[44rem] -translate-x-1/2 rounded-full bg-[#7C3AED]/15 blur-3xl"
        />

        <div className="relative mx-auto max-w-[1200px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
          <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12 lg:gap-12">
            <div className="flex flex-col justify-center lg:col-span-7">
              <div className="flex items-center justify-between gap-4">
                <p className="text-xs font-semibold tracking-widest uppercase text-[#C4B5FD]">
                  {t.home.kicker}
                </p>
                <button
                  type="button"
                  onClick={onToggleLanguage}
                  aria-label={t.switchLanguageLabel}
                  className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-[#322952] bg-[#141122] px-3 py-1 text-xs font-semibold text-[#F5F3FF] transition-colors hover:border-[#8B5CF6]/60 hover:bg-[#1D1831] whitespace-nowrap shrink-0"
                >
                  <Globe className="h-3.5 w-3.5 text-[#A78BFA]" aria-hidden="true" />
                  <span>{t.switchLanguage}</span>
                </button>
              </div>

              <h1
                className="mt-4 font-display text-4xl font-bold leading-[1.15] tracking-tight text-[#F5F3FF] sm:text-5xl"
                style={{ textWrap: 'balance' }}
              >
                {t.home.heroTitle}
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-[#A8A1C2]">
                {t.home.heroSubtitle}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('/products')}
                  className="inline-flex min-h-[46px] items-center gap-2 rounded-lg bg-[#7C3AED] px-6 py-3 text-sm font-semibold text-white shadow-[0_8px_26px_-6px_rgba(124,58,237,0.68)] transition-all duration-150 hover:bg-[#6D28D9] active:scale-[0.98] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
                >
                  <span>{t.home.ctaPrimary}</span>
                  <ArrowRight className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('/products?category=Keyboards')}
                  className="inline-flex min-h-[46px] items-center rounded-lg border border-[#322952] bg-[#141122] px-5 py-3 text-sm font-semibold text-[#F5F3FF] transition-colors duration-150 hover:border-[#8B5CF6]/60 hover:bg-[#1D1831] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
                >
                  {t.home.ctaSecondary}
                </button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="mx-auto max-w-md overflow-hidden rounded-2xl border border-[#3B2A6B] bg-[#090811] shadow-[0_24px_60px_-24px_rgba(139,92,246,0.5)]">
                <ProductImage
                  src={HERO_IMAGE}
                  alt={t.home.heroImageAlt}
                  title={t.brand}
                  imageTone="dark"
                  aspectClass="aspect-[16/10] max-h-[260px]"
                  priority
                />
              </div>
            </div>
          </div>

          {/* 4-Column Studio Guarantees Strip */}
          <div className="mt-10 grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-[#261F40] bg-[#261F40] sm:grid-cols-2 lg:grid-cols-4">
            {t.home.guarantees.map((item) => (
              <div key={item.title} className="bg-[#0E0C18] p-5">
                <p className="font-display text-sm font-semibold text-[#F5F3FF]">
                  {item.title}
                </p>
                <p className="mt-1 text-xs leading-relaxed text-[#A8A1C2]">
                  {item.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 2: Featured Collection */}
      <section className="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
        <div className="flex flex-col items-start justify-between gap-4 border-b border-[#261F40] pb-6 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-semibold tracking-widest uppercase text-[#C4B5FD]">
              {t.home.featuredKicker}
            </p>
            <h2 className="mt-2 font-display text-2xl font-bold tracking-tight text-[#F5F3FF] sm:text-3xl">
              {t.home.featuredTitle}
            </h2>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('/products')}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#DDD6FE] underline-offset-4 hover:text-white hover:underline whitespace-nowrap"
          >
            <span>{t.home.viewAll(products.length)}</span>
            <ArrowRight className="h-4 w-4 rtl:rotate-180" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              lang={lang}
              product={product}
              onOpenProduct={(slug) => onNavigate(`/products/${slug}`)}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      </section>

      {/* Section 3: Organized Hardware Groups */}
      <section className="border-t border-[#261F40] bg-[#0B0914]/80">
        <div className="mx-auto max-w-[1200px] px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <p className="text-xs font-semibold tracking-widest uppercase text-[#C4B5FD]">
                {t.home.craftKicker}
              </p>
              <h2
                className="mt-3 font-display text-2xl font-bold tracking-tight text-[#F5F3FF] sm:text-3xl"
                style={{ textWrap: 'balance' }}
              >
                {t.home.craftTitle}
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-[#A8A1C2]">
                {t.home.craftBody}
              </p>

              <dl className="mt-8 grid grid-cols-2 gap-6 border-t border-[#261F40] pt-6">
                <div>
                  <dt className="text-xs text-[#A8A1C2]">
                    {t.home.uniformPriceLabel}
                  </dt>
                  <dd className="mt-1 font-mono text-xl font-semibold text-[#DDD6FE] tabular-nums">
                    {t.home.uniformPriceValue}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-[#A8A1C2]">
                    {t.home.dispatchLabel}
                  </dt>
                  <dd className="mt-1 font-mono text-xl font-semibold text-[#F5F3FF] tabular-nums">
                    {t.home.dispatchValue}
                  </dd>
                </div>
              </dl>
            </div>

            <div className="lg:col-span-7">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {PRODUCT_CATEGORIES.map((category, index) => {
                  const count = products.filter((p) => p.category === category).length;
                  return (
                    <button
                      key={category}
                      type="button"
                      onClick={() =>
                        onNavigate(
                          `/products?category=${encodeURIComponent(category)}`
                        )
                      }
                      className="group flex items-center justify-between rounded-xl border border-[#261F40] bg-[#0E0C18] p-5 text-start transition-all duration-150 hover:border-[#8B5CF6]/70 hover:bg-[#141122] hover:shadow-[0_12px_28px_-14px_rgba(139,92,246,0.45)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA]"
                    >
                      <div>
                        <span className="font-mono text-xs text-[#A78BFA] tabular-nums">
                          0{index + 1}.
                        </span>
                        <p className="mt-1 font-display text-base font-semibold text-[#F5F3FF]">
                          {getCategoryLabel(category, lang)}
                        </p>
                        <p className="mt-0.5 text-xs text-[#A8A1C2] tabular-nums">
                          {count}{' '}
                          {count === 1
                            ? t.home.productSingular
                            : t.home.productPlural}{' '}
                          · {formatPrice(750, lang)}
                        </p>
                      </div>
                      <ArrowRight
                        className="h-4 w-4 text-[#A8A1C2] transition-transform duration-150 group-hover:translate-x-1 rtl:rotate-180 rtl:group-hover:-translate-x-1 group-hover:text-[#DDD6FE]"
                        aria-hidden="true"
                      />
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
