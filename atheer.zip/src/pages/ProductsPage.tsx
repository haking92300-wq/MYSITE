import { useEffect, useState } from 'react';
import { Search, X } from 'lucide-react';
import { PRODUCT_CATEGORIES } from '../data/products';
import type { Language, Product, ProductCategory, SortOption } from '../types/store';
import { getCategoryLabel, UI_COPY } from '../i18n/translations';
import { filterAndSortProducts } from '../utils/storeLogic';
import { ProductCard } from '../components/ProductCard';

interface ProductsPageProps {
  lang: Language;
  products: Product[];
  initialCategory?: ProductCategory | 'All';
  onNavigate: (path: string) => void;
  onAddToCart: (product: Product, variant: string) => void;
}

export function ProductsPage({
  lang,
  products,
  initialCategory = 'All',
  onNavigate,
  onAddToCart,
}: ProductsPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<
    ProductCategory | 'All'
  >(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('featured');
  const t = UI_COPY[lang];

  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  const filteredProducts = filterAndSortProducts(products, {
    category: selectedCategory,
    query: searchQuery,
    sort: sortOption,
  });

  const showGroupedSections =
    selectedCategory === 'All' && searchQuery.trim() === '';

  const handleCategoryChange = (category: ProductCategory | 'All') => {
    setSelectedCategory(category);
    const nextPath =
      category === 'All'
        ? '/products'
        : `/products?category=${encodeURIComponent(category)}`;
    window.history.replaceState(null, '', nextPath);
  };

  const resetFilters = () => {
    setSelectedCategory('All');
    setSearchQuery('');
    setSortOption('featured');
    window.history.replaceState(null, '', '/products');
  };

  return (
    <section className="mx-auto max-w-[1200px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
      <div className="border-b border-[#261F40] pb-8">
        <p className="text-xs font-semibold tracking-widest uppercase text-[#C4B5FD]">
          {t.catalog.kicker}
        </p>
        <div className="mt-2 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight text-[#F5F3FF] sm:text-4xl">
              {t.catalog.title}
            </h1>
            <p className="mt-2 text-sm text-[#A8A1C2]">{t.catalog.subtitle}</p>
          </div>
          <p className="font-mono text-xs text-[#A8A1C2] tabular-nums whitespace-nowrap">
            {t.catalog.showing(filteredProducts.length, products.length)}
          </p>
        </div>

        {/* Search & Sort Controls */}
        <div className="mt-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full lg:max-w-sm">
            <label htmlFor="catalog-search" className="sr-only">
              {t.catalog.searchLabel}
            </label>
            <Search
              className="pointer-events-none absolute top-1/2 start-3.5 h-4 w-4 -translate-y-1/2 text-[#A8A1C2]"
              aria-hidden="true"
            />
            <input
              id="catalog-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.catalog.searchPlaceholder}
              className="h-11 w-full rounded-lg border border-[#2A2246] bg-[#0E0C18] pe-10 ps-10 text-sm text-[#F5F3FF] placeholder:text-[#7E769B] focus:border-[#8B5CF6] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label={t.catalog.clearSearch}
                className="absolute top-1/2 end-2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-md text-[#A8A1C2] hover:bg-[#1D1831] hover:text-[#F5F3FF]"
              >
                <X className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-3 self-start lg:self-auto">
            <label
              htmlFor="catalog-sort"
              className="text-xs font-medium text-[#A8A1C2] whitespace-nowrap"
            >
              {t.catalog.sortBy}
            </label>
            <select
              id="catalog-sort"
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as SortOption)}
              className="h-11 rounded-lg border border-[#2A2246] bg-[#0E0C18] px-3.5 text-sm font-medium text-[#F5F3FF] focus:border-[#8B5CF6] focus:outline-none"
            >
              <option value="featured">{t.catalog.sortFeatured}</option>
              <option value="rating-desc">{t.catalog.sortRating}</option>
              <option value="name-asc">{t.catalog.sortName}</option>
            </select>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div
          role="tablist"
          aria-label={t.catalog.kicker}
          className="mt-6 flex flex-wrap items-center gap-1.5 rounded-xl border border-[#261F40] bg-[#0E0C18] p-1.5"
        >
          {(['All', ...PRODUCT_CATEGORIES] as const).map((category) => {
            const active = selectedCategory === category;
            return (
              <button
                key={category}
                role="tab"
                type="button"
                aria-selected={active}
                onClick={() => handleCategoryChange(category)}
                className={`min-h-[38px] rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A78BFA] ${
                  active
                    ? 'bg-[#7C3AED] text-white shadow-[0_4px_14px_rgba(124,58,237,0.45)]'
                    : 'text-[#A8A1C2] hover:bg-[#161229] hover:text-[#F5F3FF]'
                }`}
              >
                {getCategoryLabel(category, lang)}
              </button>
            );
          })}
        </div>
      </div>

      {/* Product Grid Organized into Category Groups or Filtered Results */}
      {filteredProducts.length === 0 ? (
        <div className="my-16 flex flex-col items-center justify-center rounded-2xl border border-[#261F40] bg-[#0E0C18] px-6 py-16 text-center">
          <h2 className="font-display text-xl font-semibold text-[#F5F3FF]">
            {t.catalog.emptyTitle}
          </h2>
          <p className="mt-2 max-w-md text-sm text-[#A8A1C2]">
            {t.catalog.emptyBody(
              searchQuery,
              getCategoryLabel(selectedCategory, lang)
            )}
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="mt-6 inline-flex min-h-[44px] items-center rounded-lg bg-[#7C3AED] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#6D28D9]"
          >
            {t.catalog.resetFilters}
          </button>
        </div>
      ) : showGroupedSections ? (
        <div className="mt-10 space-y-14">
          {PRODUCT_CATEGORIES.map((category, index) => {
            const groupItems = filteredProducts.filter(
              (product) => product.category === category
            );
            if (groupItems.length === 0) return null;

            return (
              <div key={category} aria-label={getCategoryLabel(category, lang)}>
                <div className="flex items-baseline justify-between gap-4 border-b border-[#261F40] pb-4">
                  <div className="flex items-baseline gap-3">
                    <span className="font-mono text-xs font-medium text-[#A78BFA] tabular-nums">
                      0{index + 1}.
                    </span>
                    <h2 className="font-display text-xl font-bold text-[#F5F3FF] sm:text-2xl">
                      {getCategoryLabel(category, lang)}
                    </h2>
                  </div>
                  <span className="font-mono text-xs text-[#A8A1C2] tabular-nums">
                    {groupItems.length}{' '}
                    {groupItems.length === 1
                      ? t.home.productSingular
                      : t.home.productPlural}
                  </span>
                </div>

                <div className="mt-6 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                  {groupItems.map((product) => (
                    <ProductCard
                      key={product.id}
                      lang={lang}
                      product={product}
                      onOpenProduct={(slug) => onNavigate(`/products/${slug}`)}
                      onAddToCart={onAddToCart}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              lang={lang}
              product={product}
              onOpenProduct={(slug) => onNavigate(`/products/${slug}`)}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      )}
    </section>
  );
}
