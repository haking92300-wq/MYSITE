export type Language = 'ar' | 'en';

export type ProductCategory =
  | 'Keyboards'
  | 'Mice'
  | 'Headphones'
  | 'Gaming Controllers'
  | 'Microphones';

export interface ProductSpec {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  slug: string;
  sku: string;
  name: string;
  nameAr: string;
  subtitle: string;
  subtitleAr: string;
  category: ProductCategory;
  priceEgp: 750;
  rating: number;
  reviewCount: number;
  featured: boolean;
  inStock: boolean;
  image: string;
  imageTone: 'light' | 'dark';
  imageAlt: string;
  imageAltAr: string;
  variants: string[];
  variantsAr: string[];
  description: string;
  descriptionAr: string;
  highlights: string[];
  highlightsAr: string[];
  specs: ProductSpec[];
  specsAr: ProductSpec[];
}

export interface CartItem {
  productId: string;
  variant: string;
  quantity: number;
}

export type SortOption = 'featured' | 'name-asc' | 'rating-desc';

export type PaymentMethod = 'cod' | 'card-on-delivery';

export interface CheckoutFormData {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  governorate: string;
  postalCode: string;
  notes: string;
  paymentMethod: PaymentMethod;
}

export interface CheckoutValidationErrors {
  fullName?: string;
  phone?: string;
  email?: string;
  address?: string;
  governorate?: string;
  postalCode?: string;
}

export interface ConfirmedOrder {
  orderNumber: string;
  createdAt: string;
  items: Array<{
    product: Product;
    variant: string;
    quantity: number;
    lineTotalEgp: number;
  }>;
  subtotalEgp: number;
  shippingEgp: number;
  totalEgp: number;
  customer: CheckoutFormData;
}
