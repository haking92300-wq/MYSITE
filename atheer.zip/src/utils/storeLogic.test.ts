import test from 'node:test';
import assert from 'node:assert/strict';
import { HERO_IMAGE, PRODUCTS, PRODUCT_CATEGORIES, UNIFORM_PRICE_EGP } from '../data/products';
import {
  addToCart,
  buildWhatsAppOrderMessage,
  buildWhatsAppRedirectUrl,
  calculateTotals,
  createOrderConfirmation,
  filterAndSortProducts,
  formatEgp,
  formatPrice,
  getCartCount,
  removeFromCart,
  STANDARD_SHIPPING_EGP,
  updateCartQuantity,
  validateCheckoutForm,
  WHATSAPP_DISPLAY_PHONE,
  WHATSAPP_INTL_PHONE,
} from './storeLogic';

test('all 17 uploaded products are organized in 5 groups and uniformly priced at 750 EGP', () => {
  assert.equal(UNIFORM_PRICE_EGP, 750);
  assert.equal(PRODUCTS.length, 17);
  assert.equal(PRODUCT_CATEGORIES.length, 5);
  assert.ok(HERO_IMAGE.startsWith('/assets/aistudio/'));

  const seenImages = new Set<string>();
  for (const product of PRODUCTS) {
    assert.equal(product.priceEgp, 750, `${product.name} must cost 750 EGP`);
    assert.ok(
      product.image.startsWith('/assets/aistudio/'),
      `${product.name} must reference /assets/aistudio/`
    );
    assert.ok(!seenImages.has(product.image), `Duplicate image ${product.image}`);
    seenImages.add(product.image);
  }
});

test('formatEgp and formatPrice render Egyptian Pound labels in English and Arabic', () => {
  assert.equal(formatEgp(750), '750 EGP');
  assert.equal(formatEgp(1500), '1,500 EGP');
  assert.equal(formatPrice(750, 'ar'), '750 ج.م');
  assert.equal(formatPrice(1500, 'en'), '1,500 EGP');
});

test('filterAndSortProducts filters by all 5 categories and English or Arabic search query accurately', () => {
  const keyboards = filterAndSortProducts(PRODUCTS, { category: 'Keyboards' });
  assert.equal(keyboards.length, 5);

  const mice = filterAndSortProducts(PRODUCTS, { category: 'Mice' });
  assert.equal(mice.length, 3);

  const headphones = filterAndSortProducts(PRODUCTS, { category: 'Headphones' });
  assert.equal(headphones.length, 4);

  const controllers = filterAndSortProducts(PRODUCTS, { category: 'Gaming Controllers' });
  assert.equal(controllers.length, 3);

  const mics = filterAndSortProducts(PRODUCTS, { category: 'Microphones' });
  assert.equal(mics.length, 2);

  const arabicMouseSearch = filterAndSortProducts(PRODUCTS, { query: 'ماوس' });
  assert.equal(arabicMouseSearch.length, 3);
  assert.ok(arabicMouseSearch.every((p) => p.category === 'Mice'));

  const controllerSearch = filterAndSortProducts(PRODUCTS, { query: 'ذراع تحكم' });
  assert.equal(controllerSearch.length, 3);
  assert.ok(controllerSearch.every((p) => p.category === 'Gaming Controllers'));
});

test('cart mutations add, increment, update, and remove items cleanly', () => {
  let cart = addToCart([], 'ath-kb-k552', 'Blue Clicky Switch', 1);
  cart = addToCart(cart, 'ath-kb-k552', 'Blue Clicky Switch', 1);
  cart = addToCart(cart, 'ath-ms-purple', 'Purple Lightning Edition', 1);

  assert.equal(cart.length, 2);
  assert.equal(getCartCount(cart), 3);

  cart = updateCartQuantity(cart, 'ath-kb-k552', 'Blue Clicky Switch', 1);
  assert.equal(getCartCount(cart), 2);

  cart = removeFromCart(cart, 'ath-ms-purple', 'Purple Lightning Edition');
  assert.equal(cart.length, 1);
  assert.equal(getCartCount(cart), 1);
});

test('calculateTotals computes 750 EGP subtotals and free shipping at 1500+ EGP', () => {
  const singleItem = addToCart([], 'ath-ms-purple', 'Purple Lightning Edition', 1);
  const singleSummary = calculateTotals(singleItem, PRODUCTS);
  assert.equal(singleSummary.subtotalEgp, 750);
  assert.equal(singleSummary.shippingEgp, STANDARD_SHIPPING_EGP);
  assert.equal(singleSummary.totalEgp, 750 + STANDARD_SHIPPING_EGP);
  assert.equal(singleSummary.remainingForFreeShippingEgp, 750);

  const twoItems = addToCart(singleItem, 'ath-hd-cat', 'Cosmic Purple RGB', 1);
  const twoSummary = calculateTotals(twoItems, PRODUCTS);
  assert.equal(twoSummary.subtotalEgp, 1500);
  assert.equal(twoSummary.shippingEgp, 0);
  assert.equal(twoSummary.totalEgp, 1500);
  assert.equal(twoSummary.remainingForFreeShippingEgp, 0);
});

test('validateCheckoutForm requires only customer name while keeping optional data list fields valid', () => {
  const missingNameErrors = validateCheckoutForm({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    governorate: '',
    postalCode: '',
    notes: '',
    paymentMethod: 'cod',
  });
  assert.ok(missingNameErrors.fullName);

  const nameOnlyValid = validateCheckoutForm({
    fullName: 'Omar Hassan',
    phone: '',
    email: '',
    address: '',
    governorate: 'Cairo',
    postalCode: '',
    notes: '',
    paymentMethod: 'cod',
  });
  assert.deepEqual(nameOnlyValid, {});

  const badEmailOrPhone = validateCheckoutForm({
    fullName: 'Karim Mansour',
    phone: '123',
    email: 'bad-email',
    address: '',
    governorate: 'Cairo',
    postalCode: '',
    notes: '',
    paymentMethod: 'cod',
  });
  assert.ok(badEmailOrPhone.phone);
  assert.ok(badEmailOrPhone.email);
});

test('createOrderConfirmation and WhatsApp redirect target 01033528258 with order details', () => {
  assert.equal(WHATSAPP_DISPLAY_PHONE, '01033528258');
  assert.equal(WHATSAPP_INTL_PHONE, '201033528258');

  const cart = addToCart([], 'ath-ct-dualsense', 'Arctic White & Black', 2);
  const order = createOrderConfirmation(
    cart,
    PRODUCTS,
    {
      fullName: 'Nour El-Din',
      phone: '',
      email: '',
      address: '22 Abbas El-Akkad St, Nasr City',
      governorate: 'Cairo',
      postalCode: '',
      notes: '',
      paymentMethod: 'cod',
    },
    4829
  );

  assert.equal(order.orderNumber, 'ATH-4829');
  assert.equal(order.subtotalEgp, 1500);
  assert.equal(order.shippingEgp, 0);
  assert.equal(order.totalEgp, 1500);

  const message = buildWhatsAppOrderMessage(order, 'ar');
  assert.ok(message.includes('Nour El-Din'));
  assert.ok(message.includes('#ATH-4829'));
  assert.ok(message.includes('1,500 ج.م'));

  const url = buildWhatsAppRedirectUrl(message);
  assert.ok(url.startsWith('https://wa.me/201033528258?text='));
  assert.ok(decodeURIComponent(url).includes('Nour El-Din'));
});
