import { UNIFORM_PRICE_EGP } from '../data/products';
import type {
  CartItem,
  CheckoutFormData,
  CheckoutValidationErrors,
  ConfirmedOrder,
  Language,
  Product,
  ProductCategory,
  SortOption,
} from '../types/store';

export const FREE_SHIPPING_THRESHOLD_EGP = 1500;
export const STANDARD_SHIPPING_EGP = 65;

export function formatEgp(amount: number): string {
  return `${amount.toLocaleString('en-US')} EGP`;
}

export function formatPrice(amount: number, lang: Language = 'ar'): string {
  const formatted = amount.toLocaleString('en-US');
  return lang === 'ar' ? `${formatted} ج.م` : `${formatted} EGP`;
}

export function filterAndSortProducts(
  products: Product[],
  options: {
    category?: ProductCategory | 'All';
    query?: string;
    sort?: SortOption;
  }
): Product[] {
  const category = options.category ?? 'All';
  const query = (options.query ?? '').trim().toLowerCase();
  const sort = options.sort ?? 'featured';

  const filtered = products.filter((product) => {
    const matchesCategory = category === 'All' || product.category === category;
    if (!matchesCategory) return false;

    if (!query) return true;
    const haystack =
      `${product.name} ${product.nameAr} ${product.subtitle} ${product.subtitleAr} ${product.category} ${product.sku}`.toLowerCase();
    return haystack.includes(query);
  });

  return [...filtered].sort((a, b) => {
    if (sort === 'name-asc') {
      return a.name.localeCompare(b.name);
    }
    if (sort === 'rating-desc') {
      return b.rating - a.rating || b.reviewCount - a.reviewCount;
    }
    if (a.featured !== b.featured) {
      return a.featured ? -1 : 1;
    }
    return b.rating - a.rating;
  });
}

export function addToCart(
  cart: CartItem[],
  productId: string,
  variant: string,
  quantity = 1
): CartItem[] {
  const safeQty = Math.max(1, Math.floor(quantity));
  const existingIndex = cart.findIndex(
    (item) => item.productId === productId && item.variant === variant
  );

  if (existingIndex === -1) {
    return [...cart, { productId, variant, quantity: safeQty }];
  }

  return cart.map((item, idx) =>
    idx === existingIndex ? { ...item, quantity: item.quantity + safeQty } : item
  );
}

export function updateCartQuantity(
  cart: CartItem[],
  productId: string,
  variant: string,
  quantity: number
): CartItem[] {
  if (quantity <= 0) {
    return removeFromCart(cart, productId, variant);
  }
  const safeQty = Math.min(99, Math.floor(quantity));
  return cart.map((item) =>
    item.productId === productId && item.variant === variant
      ? { ...item, quantity: safeQty }
      : item
  );
}

export function removeFromCart(
  cart: CartItem[],
  productId: string,
  variant: string
): CartItem[] {
  return cart.filter(
    (item) => !(item.productId === productId && item.variant === variant)
  );
}

export function getCartCount(cart: CartItem[]): number {
  return cart.reduce((sum, item) => sum + item.quantity, 0);
}

export function calculateTotals(cart: CartItem[], products: Product[]) {
  const productMap = new Map(products.map((p) => [p.id, p]));
  const detailedItems = cart
    .map((item) => {
      const product = productMap.get(item.productId);
      if (!product) return null;
      const lineTotalEgp = product.priceEgp * item.quantity;
      return {
        product,
        variant: item.variant,
        quantity: item.quantity,
        lineTotalEgp,
      };
    })
    .filter((entry): entry is NonNullable<typeof entry> => entry !== null);

  const subtotalEgp = detailedItems.reduce((sum, item) => sum + item.lineTotalEgp, 0);
  const shippingEgp =
    subtotalEgp === 0
      ? 0
      : subtotalEgp >= FREE_SHIPPING_THRESHOLD_EGP
        ? 0
        : STANDARD_SHIPPING_EGP;
  const totalEgp = subtotalEgp + shippingEgp;
  const remainingForFreeShippingEgp = Math.max(
    0,
    FREE_SHIPPING_THRESHOLD_EGP - subtotalEgp
  );

  return {
    detailedItems,
    subtotalEgp,
    shippingEgp,
    totalEgp,
    remainingForFreeShippingEgp,
    unitPriceEgp: UNIFORM_PRICE_EGP,
  };
}

export const WHATSAPP_DISPLAY_PHONE = '01033528258';
export const WHATSAPP_INTL_PHONE = '201033528258';

export function validateCheckoutForm(
  data: CheckoutFormData,
  lang: Language = 'en'
): CheckoutValidationErrors {
  const errors: CheckoutValidationErrors = {};
  const isAr = lang === 'ar';

  if (!data.fullName.trim() || data.fullName.trim().length < 2) {
    errors.fullName = isAr
      ? 'يرجى إدخال اسمك لإتمام الطلب.'
      : 'Please enter your name to complete the order.';
  }

  if (data.phone.trim()) {
    const digits = data.phone.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 15) {
      errors.phone = isAr
        ? 'أدخل رقم هاتف صحيح (10 إلى 15 رقماً) أو اتركه فارغاً.'
        : 'Enter a valid phone number (10–15 digits) or leave blank.';
    }
  }

  if (data.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.email = isAr
      ? 'أدخل بريداً إلكترونياً صحيحاً أو اتركه فارغاً.'
      : 'Enter a valid email address or leave blank.';
  }

  return errors;
}

export function buildWhatsAppOrderMessage(
  order: Pick<
    ConfirmedOrder,
    'orderNumber' | 'items' | 'subtotalEgp' | 'shippingEgp' | 'totalEgp' | 'customer'
  >,
  lang: Language = 'ar'
): string {
  const isAr = lang === 'ar';
  const lines: string[] = [];

  if (isAr) {
    lines.push(`مرحباً أثير، أرغب في تأكيد طلبي رقم #${order.orderNumber}`);
    lines.push(`الاسم: ${order.customer.fullName.trim()}`);
    if (order.customer.phone.trim()) {
      lines.push(`رقم الهاتف: ${order.customer.phone.trim()}`);
    }
    if (order.customer.governorate.trim()) {
      lines.push(`المحافظة: ${order.customer.governorate.trim()}`);
    }
    if (order.customer.address.trim()) {
      lines.push(`العنوان: ${order.customer.address.trim()}`);
    }
    if (order.customer.postalCode.trim()) {
      lines.push(`الرمز البريدي: ${order.customer.postalCode.trim()}`);
    }
    if (order.customer.email.trim()) {
      lines.push(`البريد الإلكتروني: ${order.customer.email.trim()}`);
    }
    lines.push(
      `طريقة الدفع: ${
        order.customer.paymentMethod === 'cod'
          ? 'الدفع نقداً عند الاستلام'
          : 'الدفع بالبطاقة عند الاستلام (POS)'
      }`
    );
    if (order.customer.notes.trim()) {
      lines.push(`ملاحظات: ${order.customer.notes.trim()}`);
    }
    lines.push('');
    lines.push('المنتجات:');
    for (const item of order.items) {
      lines.push(
        `- ${item.product.nameAr} (${item.variant}) × ${item.quantity} = ${formatPrice(item.lineTotalEgp, 'ar')}`
      );
    }
    lines.push('');
    lines.push(`المجموع الفرعي: ${formatPrice(order.subtotalEgp, 'ar')}`);
    lines.push(
      `الشحن: ${order.shippingEgp === 0 ? 'مجاني' : formatPrice(order.shippingEgp, 'ar')}`
    );
    lines.push(`الإجمالي: ${formatPrice(order.totalEgp, 'ar')}`);
  } else {
    lines.push(`Hello Atheer, I would like to confirm Order #${order.orderNumber}`);
    lines.push(`Name: ${order.customer.fullName.trim()}`);
    if (order.customer.phone.trim()) {
      lines.push(`Phone: ${order.customer.phone.trim()}`);
    }
    if (order.customer.governorate.trim()) {
      lines.push(`Governorate: ${order.customer.governorate.trim()}`);
    }
    if (order.customer.address.trim()) {
      lines.push(`Address: ${order.customer.address.trim()}`);
    }
    if (order.customer.postalCode.trim()) {
      lines.push(`Postal Code: ${order.customer.postalCode.trim()}`);
    }
    if (order.customer.email.trim()) {
      lines.push(`Email: ${order.customer.email.trim()}`);
    }
    lines.push(
      `Payment: ${
        order.customer.paymentMethod === 'cod'
          ? 'Cash on Delivery'
          : 'Card on Delivery (POS)'
      }`
    );
    if (order.customer.notes.trim()) {
      lines.push(`Notes: ${order.customer.notes.trim()}`);
    }
    lines.push('');
    lines.push('Items:');
    for (const item of order.items) {
      lines.push(
        `- ${item.product.name} (${item.variant}) × ${item.quantity} = ${formatPrice(item.lineTotalEgp, 'en')}`
      );
    }
    lines.push('');
    lines.push(`Subtotal: ${formatPrice(order.subtotalEgp, 'en')}`);
    lines.push(
      `Shipping: ${order.shippingEgp === 0 ? 'Complimentary' : formatPrice(order.shippingEgp, 'en')}`
    );
    lines.push(`Total: ${formatPrice(order.totalEgp, 'en')}`);
  }

  return lines.join('\n');
}

export function buildWhatsAppRedirectUrl(
  message: string,
  phoneIntl: string = WHATSAPP_INTL_PHONE
): string {
  const cleanDigits = phoneIntl.replace(/\D/g, '');
  return `https://wa.me/${cleanDigits}?text=${encodeURIComponent(message)}`;
}

export function createOrderConfirmation(
  cart: CartItem[],
  products: Product[],
  customer: CheckoutFormData,
  seedNumber = Math.floor(1000 + Math.random() * 9000)
): ConfirmedOrder {
  const summary = calculateTotals(cart, products);
  return {
    orderNumber: `ATH-${seedNumber}`,
    createdAt: new Date().toISOString(),
    items: summary.detailedItems,
    subtotalEgp: summary.subtotalEgp,
    shippingEgp: summary.shippingEgp,
    totalEgp: summary.totalEgp,
    customer,
  };
}
